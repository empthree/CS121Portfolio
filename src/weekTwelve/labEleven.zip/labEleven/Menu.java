package weekTwelve.labEleven;

import java.util.Scanner;

public class Menu {

    private Pokedex pokedex;

    Scanner scan = new Scanner(System.in);

    public Menu() {
        this.pokedex = new Pokedex();
    }

    public void displayMenu() {

        while (true) {
            System.out.println("\n***** MENU *****");
            System.out.println("Please make a selection:" +
                    "\n1) Add a Pokemon" +
                    "\n2) Remove a Pokemon" +
                    "\n3) Display Pokemon info" +
                    "\n4) Display all Pokemon info" +
                    "\n5) Exit");
            int userInput = scan.nextInt();

            if (userInput == 1){
                createPokemon();
            } else if (userInput == 2){
                deletePokemon();
            } else if (userInput == 3){
                displayPokemon();
            } else if (userInput == 4){
                displayAllPokemon();
            } else if (userInput == 5){
                System.out.println("Exiting...");
                break;
            } else {
                System.out.println("Invalid entry. Please select a valid option.");
            }
        }
    }

    private void createPokemon() {

        System.out.println("Please enter your Pokemon's name: ");
        String name = scan.next();

        System.out.printf("Please enter %s's HP: ", name);
        int pokeHP = scan.nextInt();

        Pokemon pokemon = new Pokemon(name, pokeHP);

        while (true) {

            System.out.println("Please enter the name of a move, or 'q' if finished.");
            String moveName = scan.next();

            if (moveName.equalsIgnoreCase("q")) {
                break;

            } else {
                System.out.printf("Please enter %s's power: ", moveName);
                int power = scan.nextInt();

                System.out.printf("Please enter %s's speed: ", moveName);
                int speed = scan.nextInt();

                Move move = new Move(moveName, power, speed);
                pokemon.addMove(move);
            }
            pokedex.addPokemon(pokemon);
            System.out.printf("\n%s has been added to the Pokedex!\n\n", name);
        }
    }

    private void deletePokemon() {

        System.out.println("Enter the name of the Pokemon you wish to delete.");

        String name = scan.next();

        Pokemon deletePoke = pokedex.getPokemon(name);
        if(deletePoke != null) {
            pokedex.removePokemon(deletePoke);
            System.out.printf("\n%s has been removed from the Pokedex!\n\n", name);
        } else {
            System.out.println("Pokemon not found!");
        }
    }

    private void displayPokemon() {
        System.out.println("Enter the name of the Pokemon you wish to display: ");
        String name = scan.next();
        Pokemon pokemon = pokedex.getPokemon(name);
        if (pokemon == null) {
            System.out.println("Pokemon not found!");
        } else {
            System.out.println(pokemon);
        }
    }

    private void displayAllPokemon() {
        System.out.println("\n***** Pokedex *****");
        for (Pokemon pokemon : pokedex.getAllPokemon()) {
            System.out.println();
            System.out.println(pokemon);
        }
    }
}
