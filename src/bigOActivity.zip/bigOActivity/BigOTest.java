package bigOActivity;

public class BigOTest {
    public static void main(String[] args) {

        BigO x = new BigO();
        x.printOnce(4);
        x.printNTimes(4);
        x.printNSquaredTimes(3);
    }
}
