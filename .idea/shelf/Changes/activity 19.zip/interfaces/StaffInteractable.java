package weekTen.interfaces;

public class StaffInteractable implements Interactable {
    @Override
    public void interact() {
        System.out.println("Staff is managing the restaurant operations.");
    }
}
