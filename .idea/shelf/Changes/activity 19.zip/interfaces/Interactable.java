package weekTen.interfaces;

public interface Interactable {
    void interact();
}
